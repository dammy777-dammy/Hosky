const express = require("express");
const { v4: uuidv4 } = require("uuid");

const app = express();
app.use(express.static("public"));
app.use(express.json());

let users = {};
let leaderboard = [];

let game = {
  multiplier: 1.0,
  crashPoint: Math.random() * 5 + 1.5,
  running: false
};

setInterval(() => {
  if (game.running) {
    game.multiplier += 0.1;
    if (game.multiplier >= game.crashPoint) {
      game.running = false;
      game.multiplier = 1.0;
      game.crashPoint = Math.random() * 5 + 1.5;
    }
  }
}, 100);

app.post("/login", (req, res) => {
  const { username } = req.body;
  if (!users[username]) {
    users[username] = { balance: 1000, id: uuidv4() };
  }
  res.json(users[username]);
});

app.post("/balance", (req, res) => {
  const { username } = req.body;
  res.json({ balance: users[username].balance });
});

app.post("/bet", (req, res) => {
  const { username, amount } = req.body;
  if (amount > users[username].balance) return res.json({ success: false });
  users[username].balance -= amount;
  game.running = true;
  res.json({ success: true });
});

app.post("/cashout", (req, res) => {
  const { username, amount } = req.body;
  if (!game.running) return res.json({ success: false });
  const win = amount * game.multiplier;
  users[username].balance += win;
  leaderboard.push({ username, win });
  res.json({ success: true, win });
});

app.get("/leaderboard", (req, res) => {
  res.json(leaderboard.slice(-10));
});

app.get("/game", (req, res) => {
  res.json(game);
});

app.listen(process.env.PORT || 3000, () => {
  console.log("Server running");
});
